def count(phrase):
    return phrase.count('.')
