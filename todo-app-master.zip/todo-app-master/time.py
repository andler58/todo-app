def current_time(filepath='Main'):
    now = time.strftime('%b - %d - %Y %H:%M:%S')
    print('It is', now, 'right now. ')
